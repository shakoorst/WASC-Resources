#Security Extension
Displays browser security indicators