
var conn_stat = document.getElementById("conn_status");
var domain_link = document.getElementById("domain");
var cert_issuer = document.getElementById("issuer");
var site_owner = document.getElementById("owner");
var cert_valid_from = document.getElementById("valid_from");
var cert_valid_to = document.getElementById("valid_to");
var cookie_set = document.getElementById("cookie");

self.port.on("certificate", function handleMyMessage(cert_info) {
  
  if(cert_info[0]!='secure connection')
  {
    conn_stat.innerHTML='Connection is not secured';
  }
  else
  {
    conn_stat.innerHTML=cert_info[0];
  }
  
  domain_link.innerHTML=cert_info[1];
  
  if(cert_info[2]==undefined)
  {
  	cert_issuer.innerHTML="Not Available";
  }
  else
  {
  	 cert_issuer.innerHTML=cert_info[2];

  }

  if(cert_info[3]==undefined)
  {
  	site_owner.innerHTML="Not Available";
  }
  else
  {
  	site_owner.innerHTML=cert_info[3];
  }

  if(cert_info[5]==undefined)
  {
  	cert_valid_from.innerHTML="Not Available";
  }
  else
  {
  	cert_valid_from.innerHTML=cert_info[5];
  }

  if(cert_info[6]==undefined)
  {
  	cert_valid_to.innerHTML="Not Available";
  }
  else
  {
  	 cert_valid_to.innerHTML=cert_info[6];

  }
 
 
});

self.port.on("cookie", function handleMyCookie(cookie) {

	var info="This page sets " + cookie +" trackers";
  
    cookie_set.innerHTML=info;
});